SAS Viya Orders is a command-line interface (CLI) that calls the 
appropriate SAS Viya Orders API endpoint to obtain the requested 
deployment assets for a specified SAS Viya software order.
To download the latest version:

git clone https://github.com/sassoftware/viya4-orders-cli

Build the docker image:

cd viya4-orders-cli
docker build . -t viya4-orders-cli
