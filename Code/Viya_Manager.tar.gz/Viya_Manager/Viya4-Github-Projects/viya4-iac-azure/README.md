This project contains Terraform scripts to provision the Microsoft
Azure Cloud infrastructure resources that are required to deploy
Viya 4 product offerings. To download the latest version:

git clone https://github.com/sassoftware/viya4-iac-azure

Build the docker image:

cd viya4-iac-azure
docker build . -t viya4-iac-azure
