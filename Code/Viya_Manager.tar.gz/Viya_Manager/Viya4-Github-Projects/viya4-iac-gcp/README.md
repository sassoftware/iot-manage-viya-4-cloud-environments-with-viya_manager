This project contains Terraform scripts to provision the Google
Cloud infrastructure resources that are required to deploy SAS
Viya 4 product offerings. To download the latest version:

git clone https://github.com/sassoftware/viya4-iac-gcp

Build the docker image:

cd viya4-iac-gcp
docker build . -t viya4-iac-gcp
