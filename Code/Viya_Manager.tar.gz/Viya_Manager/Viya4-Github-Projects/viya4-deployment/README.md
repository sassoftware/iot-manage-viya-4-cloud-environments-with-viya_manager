This project contains Ansible code that creates a baseline 
cluster in an existing Kubernetes environment for use with 
SAS Viya 4, generates the manifest for a SAS Viya software 
order, and deploys that order onto the Kubernetes cluster.
To download the latest version:

git clone https://github.com/sassoftware/viya4-deployment

Build the docker image:

cd viya4-deployment
docker build . -t viya4-deployment
