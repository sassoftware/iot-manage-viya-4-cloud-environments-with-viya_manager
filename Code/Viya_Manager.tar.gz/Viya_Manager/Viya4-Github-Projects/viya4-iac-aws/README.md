This project contains Terraform scripts to provision the Amazon
Cloud infrastructure resources that are required to deploy SAS
Viya 4 product offerings. To download the latest version:

git clone https://github.com/sassoftware/viya4-iac-aws

Build the docker image:

cd viya4-iac-aws
docker build . -t viya4-iac-aws
