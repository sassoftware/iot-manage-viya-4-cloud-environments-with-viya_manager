Filebrowser is an utility to allow users to download, upload,
and manage files on a server in a controlled way. To install
it, run the following command:

curl -fsSL https://raw.githubusercontent.com/filebrowser/get/master/get.sh | bash

The filebrowser executable will be added to /usr/local/bin.
As root, create a folder called /usr/local/share/filebrowser:

mkdir /usr/local/share/filebrowser

To initialize the database for filebrowser, run the following 
command:

cd /usr/local/share/filebrowser && rm -rf filebrowser.db
filebrowser config init --address 0.0.0.0 --branding.name 'File Browser Viya-iot-1' --port 18080 --root / --branding.files "/usr/local/share/filebrowser"

As root, switch directory to /etc/systemd/system to create a
service to start filebrowser automatically when the server
starts:

cd /etc/systemd/system
cat << EOF > filebrowser.service
# NOTE: DO NOT DELETE THIS FILE!
#
# Start the filebrowser utility to allow users to load files
# into shared Viya folders

[Unit]
Description=Viya filebrowser utility

[Service]
ExecStart=/usr/local/bin/filebrowser -d /usr/local/share/filebrowser/filebrowser.db
Restart=always
TimeoutStartSec=180

[Install]
WantedBy=multi-user.target
EOF

To refresh the list of services,and to start and enable the filebrowser service, use
the following commands:

systemctl daemon-reload
systemctl start filebrowser
systemctl enable filebrowser.service

To add users to filebrowser, run the Generate_filebrowser_user_list command found in
this folder:

./Generate_filebrowser_user_list

Capture the output, then run it on the server and folder where filebrowser is installed.
You might have to stop filebrowser before making changes to its database. To do so, run
the following command:

systemctl stop filebrowser

Once the users have been created, start filebrowser using the following command:

systemctl start filebrowser

IMPORTANT: To be able to access Filebrowser, a network rule has to be created for
the Cloud server(s) where Filebrowser is runnning. The rule has to be such to open
port 18080 (or whatever port one wants to use) for external access.
