This directory contains the following folders:

- Databases :
  Contains the manifests necessary to install a variety of
  databases like Oracle, MSSQL, MySQL, and PostGreSQL.

- Jupyter:  
  Contains the manifests needed to install and customize Anaconda 
  Jupyter on the cluster.

- JupyterLab:
  Contains the manifest needed to install JupyterLab. Compared to 
  Jupyter, it provides support for Julia and R in addition to Python.

- Monitoring:
  Contains a Prometheus-based monitoring stack that includes
  useful dashboards to monitor Viya as well as SAS Event Stream
  Processing projects.
