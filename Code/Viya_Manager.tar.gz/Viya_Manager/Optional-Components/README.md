This directory contains the following folders:

- Databases :
  Contains the manifests necessary to install a variety of
  databases like Oracle, MSSQL, MySQL, and PostGreSQL.

- External_languages :
  Contains the tarred images for Python and R to install
  on the cluster.

- Filebrowser :
  Contains the file needed to install and run the Filebrowser tool
  to allow users to upload/download files into/from kubernetes mount
  points.

- Jupyter:  
  Contains the manifests needed to install and customize Anaconda 
  Jupyter on the cluster.

- JupyterLab:
  Contains the manifest needed to install JupyterLab. Compared to 
  Jupyter, it provides support for Julia and R in addition to Python.
