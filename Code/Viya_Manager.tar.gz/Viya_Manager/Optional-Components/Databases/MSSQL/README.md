This folder contains a series of manifests designed to deploy MS SQL Server
2019 on Kubernetes. The installation requires a valid login for the Docker
registry that contains the MS SQL Server image.

Getting Started

- Using a browser, log on to the Docker registry site with the following
  URL:

  https://hub.docker.com/_/microsoft-mssql-server

  Before you can pull the image, you need to sign in with your Docker Hub
  account to accept the license terms. If you don't have an account, open
  one as part of the logon process.

- Once you have signed in, create the namespace where MS SQL Server will be 
  installed using the following command:

  kubectl create -f MSSQL-namespace.yaml

- A couple of options are available to create a secret to pull the image 
  from the Docker Hub registry. The first one uses the command below.
  Make sure to replace "user" and "pwd" with the Docker Hub account user
  and password from the previous step:

  kubectl create secret docker-registry mssql-image-pull-secret -n mssql --docker-server="https://index.docker.io/v1/" --docker -username="<user>" --docker-password="<pwd>"

  The second option requires that you log on to the Docker Hub registry
  first:

  docker login https://index.docker.io/v1/

  When prompted, enter your Docker Hub credentials then press Enter. This 
  steps creates or updates the ~/.docker/config.json file which stores
  credentials to access Docker registries. The secret can then be created
  using the following command:

  kubectl create secret generic mssql-image-pull-secret -n mssql --from-file=.dockerconfigjson=$HOME/.docker/config.json --type=kubernetes.io/dockerconfigjson

  The second technique is preferrable for the credentials stored in the
  user's config.json file are encrypted, and they wouldn't be shown in 
  clear even after decoding the secret. The same cannot be said for the
  first method.

- Create a secret to store the password for the SA user using a command
  similar to the following:

  kubectl create secret generic mssql-sa-password-secret -n mssql --from-literal=SA_PASSWORD="<password>"

- Create a configMap to set environment variables for the MS SQL Server
  container:

  kubectl create configmap mssql-database-cm --from-env-file=MSSQL.properties -n mssql

- Install MS SQL Server as a stateful set:

  kubectl apply -f MSSQL-statefulset.yaml

Testing Connectivity

- To test connectivity from within the container, use the following 
  set of commands:

  kubectl exec -it mssql-0 -n mssql -- /bin/sh
  /opt/mssql-tools/bin/sqlcmd -U sa

  When prompted, enter the password for the SA user that was used to
  create the mssql-sa-password-secret previously.

- To test connectivity in SAS, a statement similar to the following can be used:

  With SAS:

  libname x sqlsvr user=<user> pwd=<password> dsn=mssql;

  With CAS:

  caslib x desc='MSSQL Caslib'
     dataSource=(srctype='sqlserver'
                 host='mssql-0.mssql.mssql.svc.cluster.local'
                 username='sample'
                 password='<password>'
                 catalog='*'
                 odbc_dsn='MSSQL'
                 schema='dbo');

  proc casutil;
        list files;
  quit;

  Where '<password>' is the one created in the previous step and dsn=MSSQL
  correspond to the following ODBC entry:

  [MSSQL]
  Driver=/access-clients/odbc/lib/S0sqls28.so
  Description=SAS Institute, Inc 8.0 SQL Server Wire Protocol
  AlternateServers=
  AlwaysReportTriggerResults=0
  AnsiNPW=1
  ApplicationIntent=0
  ApplicationName=
  ApplicationUsingThreads=1
  AuthenticationMethod=1
  BulkBinaryThreshold=32
  BulkCharacterThreshold=-1
  BulkLoadBatchSize=1024
  BulkLoadFieldDelimiter=
  BulkLoadOptions=2
  BulkLoadRecordDelimiter=
  BulkLoadThreshold=2
  ConnectionReset=0
  ConnectionRetryCount=0
  ConnectionRetryDelay=3
  CryptoProtocolVersion=TLSV1,TLSV1.1,TLSV1.2
  Database=users
  Domain=
  EnableBulkLoad=0
  EnableQuotedIdentifiers=0
  EnableServerSideCursors=1
  EncryptionMethod=0
  FailoverGranularity=0
  FailoverMode=0
  FailoverPreconnect=0
  FetchTSWTZasTimestamp=0
  FetchTWFSasTime=1
  GSSClient=native
  HostName=mssql-0.mssql.mssql.svc.cluster.local
  HostNameInCertificate=
  IANAAppCodePage=
  InitializationString=
  KeepAlive=0
  Language=
  LoadBalanceTimeout=0
  LoadBalancing=0
  LoginTimeout=15
  LogonID=
  MaxPoolSize=100
  MinPoolSize=0
  MultiSubnetFailover=0
  PacketSize=-1
  Pooling=0
  PortNumber=1433
  PRNGSeedFile=/dev/random
  PRNGSeedSource=0
  ProxyHost=
  ProxyMode=0
  ProxyPassword=
  ProxyPort=
  ProxyUser=
  QueryTimeout=0
  ReportCodepageConversionErrors=0
  SnapshotSerializable=0
  TrustStore=
  TrustStorePassword=
  ValidateServerCertificate=1
  WorkStationID=
  XMLDescribeType=-10

  For reference, the odbc.ini file is located in /opt/access-clients/odbc.

Optional Customizations

- To create the sample user and database, log on to MS SQL Server using the same 
  steps used to test connectivity, then run the following commands:

  create database users;
  go
  create login sample with password = '<password>';
  go
  use users;
  go
  create user sample for login sample;
  go
  grant alter, control to sample;
  go

- To create the Viya demo user, log on to MS SQL Server as shown in the previous
  step, then run the following commands:

  create login viya_demo with password = 'DemoPass', check_policy=off;
  go
  use users;
  go
  create user viya_demo for login viya_demo;
  go
  grant alter, control to viya_demo;
  go
