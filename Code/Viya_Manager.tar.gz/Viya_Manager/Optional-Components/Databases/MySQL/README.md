This folder contains a series of manifests for the deployment of MySQL on
Kubernetes. The installation requires a valid login for the Docker registry
that contains the MySQL image.

Getting Started

- Using a browser, log on to the Docker registry site with the following
  URL:

  https://hub.docker.com/_/mysql

  Before you can pull the image, you need to sign in with your Docker Hub
  account to accept the license terms. If you don't have an account, open
  one as part of the logon process.

- Once you have signed in, create the install namespace for MySQL using   
  the following command:

  kubectl create -f MySQL-namespace.yaml

- A couple of options are available to create a secret to pull the image 
  from the Docker Hub registry. The first one uses the command below.
  Make sure to replace "user" and "pwd" with the Docker Hub account user
  and password from the previous step:

  kubectl create secret docker-registry mysql-image-pull-secret -n mysql --docker-server="https://index.docker.io/v1/" --docker -username="<user>" --docker-password="<pwd>"

  The second option requires that you log on to the Docker Hub registry
  first:

  docker login https://index.docker.io/v1/

  When prompted, enter your Docker Hub credentials then press Enter. This 
  steps creates or updates the ~/.docker/config.json file which stores
  credentials to access Docker registries. The secret can then be created
  using the following command:

  kubectl create secret generic mysql-image-pull-secret -n mysql --from-file=.dockerconfigjson=$HOME/.docker/config.json --type=kubernetes.io/dockerconfigjson

  The second technique is preferrable for the credentials stored in the
  user's config.json file are encrypted, and they wouldn't be shown in 
  clear even after decoding the secret. The same cannot be said for the
  first method.

- Create a secret to store the password for the SA user using a command
  similar to the following:

  kubectl create secret generic mysql-root-password-secret -n mysql --from-literal=MYSQL_ROOT_PASSWORD="<password>"

- Create a configMap to set environment variables for the MySQL container:

  kubectl create configmap mysql-database-cm --from-env-file=MySQL.properties -n mysql

- Install MySQL Server as a stateful set:

  kubectl apply -f MySQL-statefulset.yaml

Testing Connectivity

- To test connectivity from within the container, use the following 
  set of commands:

  kubectl exec -it mysql-0 -n mysql -- /bin/sh
  mysql -p

  When prompted, enter the password for the root user that was used to
  create the mysql-root-password-secret previously.

  Optionally, use the following commands to create the sample and Viya
  demo users along with the sample database:

  create database users;
  create user 'sample'@'%' identified by "<password>";
  create user 'viya_demo'@'%' identified by 'DemoPass';
  grant all privileges on users.* to 'sample'@'%';
  grant all privileges on users.* to 'viya_demo'@'%';

- To test connectivity in SAS, a statement similar to the following can be used:

  With SAS:

  libname x mysql user=sample pwd='<password>' server='mysql-0.mysql.mysql.svc.cluster.local' database=users;

  With CAS:

  caslib x desc='MySQL Caslib' 
     dataSource=(srctype='mysql'
                 host='mysql-0.mysql.mysql.svc.cluster.local'
                 username='sample'
                 password='<password>'
                 database="users");

  proc casutil;
	list files;
  quit;

  Where '<password>' is the one created in the previous step.

- Some of the sample scenarios run by the AIoT/PQA wrapper make use of MySQL to
  load database data into CAS. For those scenarios to work, two databases called
  "aiot" and "pqa" need to be created using statements similar to the following:

  create database aiot;
  create database pqa;
  grant all privileges on aiot.* to 'viya_demo'@'%';
  grant all privileges on pqa.* to 'viya_demo'@'%';
