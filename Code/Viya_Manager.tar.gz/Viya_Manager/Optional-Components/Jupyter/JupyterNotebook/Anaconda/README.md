Create the resources needed to run Jupyter notebook on Kubernetes in
the followng order:

- Create Jupyter's namespace:
  Run anaconda-jupyter-ns.yaml (kubectl create -f anaconda-jupyter-ns.yaml)
- Create a persistent volume
  Run anaconda-jupyter-pv.yaml (kubectl create -f anaconda-jupyter-pv.yaml)
- Create a Persistent Volume Claim
  Run anaconda-jupyter-pvc.yaml (kubectl create -f anaconda-jupyter-pvc.yaml)
- Create the Jupyter deployment
  Run anaconda-jupyter-deploy.yaml (kubectl create -f anaconda-jupyter-deploy.yaml)
- Associate a service to Jupyter
  Run anaconda-jupyter-svc.yaml (kubectl create -f anaconda-jupyter-svc.yaml)
- Optionally, install the SSL certificates needed to connect to a secure Viya
  ./anaconda-jupyter-ssl.sh

Log on to the Jupyter notebook using a URL similar to the following one:

http://jupyter-iot-1.unx.sas.com

NOTE:

The Anaconda's Jupyter image is a customization of the original one
(continuumio/anaconda3). The changes applied to the image include:

- The installation of the libnuma-dev libraries
- The installation of the saspy and swat Python packages
- The installation of the SSL certificates needed to connect to CAS
- The creation of the "SASUsers" group, with a gid of 2000, the same
  gid used for the group definition in the internal LDAP server.

Once the image has been customized, it needs to be tested then saved:

- Open a browser, then type "http://jupyter-iot-1.unx.sas.com" (or similar address)
  to connect to the Junyper Notebook
- Open a new notebook and paste the following code, making sure to change
  the Viya server name as needed:

  import swat
  conn = swat.CAS('https://iot.viya-iot-1.unx.sas.com:443/cas-shared-default-http/',username='viya_demo',password='DemoPass')
  out = conn.serverstatus()
  out

  - or:

  import swat
  conn = swat.CAS('controller.sas-cas-server-default.sas-viya.svc.cluster.local','5570','viya_demo','DemoPass')
  out = conn.serverstatus()
  out
