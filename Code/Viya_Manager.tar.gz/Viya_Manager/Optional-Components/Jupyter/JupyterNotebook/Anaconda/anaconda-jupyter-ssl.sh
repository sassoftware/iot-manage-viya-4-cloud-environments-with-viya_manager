echo -ne "Downloading the SSL certificates from the CAS controller...\n"
kubectl cp sas-viya/sas-cas-server-default-controller:/security/trustedcerts.pem trustedcerts.pem

echo -ne "Uploading the SSL certificates onto Jupyter...\n"
kubectl cp trustedcerts.pem jupyter/`kubectl get pods -n jupyter | grep -i anaconda-jupyter | awk '{print $1}'`:/opt/notebooks/

echo -ne "Adding the SSL certificates to the trust store...\n"
kubectl exec -it `kubectl get pods -n jupyter | grep -i anaconda-jupyter | awk '{print $1}'` -n jupyter -- bin/sh -c "cd /opt/conda/ssl && mv /opt/notebooks/trustedcerts.pem cacert.pem.new && cat cacert.pem >> cacert.pem.new && mv cacert.pem cacert.pem.orig && mv cacert.pem.new cacert.pem && ls -al"

echo -ne "Cleaning up...\n"
rm -rf trustedcerts.pem

echo -ne "Done!\n"
exit 0
