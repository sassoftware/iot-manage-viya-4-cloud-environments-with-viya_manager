#!/usr/bin/env bash
#==============================================================#
# Install certificates for Jupyter                             #
#==============================================================#
jupyter_lab_pod=`kubectl get pods -n jupyter-lab | grep -vE 'service|NAME' | awk '{print $1}'`
cas_controller_pod=`kubectl get pods -n sas-viya | grep controller | awk '{print $1}'`

if [ ! -z $jupyter_lab_pod ] && [ ! -z $cas_controller_pod ]; then
   echo -ne "Verifying semaphore...\n"
   if [ directory == $(kubectl exec -it $jupyter_lab_pod -n jupyter-lab -- /bin/sh -c "ls -al /tmp/ssl.sem" | awk -v RS='\r\n' '{print $9}') ]; then
      echo -ne "Downloading the SSL certificates from the CAS controller...\n"
      kubectl cp sas-viya/$cas_controller_pod:/security/trustedcerts.pem trustedcerts.pem

      echo -ne "Uploading the SSL certificates onto JupyterLab...\n"
      jupyter_lab_pod=`kubectl get pods -n jupyter-lab | grep -vE 'service|NAME' | awk '{print $1}'`
      kubectl cp trustedcerts.pem jupyter-lab/$jupyter_lab_pod:/opt/notebooks/

      echo -ne "Adding the SSL certificates to the trust store...\n"
      kubectl exec -it $jupyter_lab_pod -n jupyter-lab -- /bin/sh -c "cd /opt/conda/ssl && mv /opt/notebooks/trustedcerts.pem cacert.pem.new && cat cacert.pem >> cacert.pem.new && mv cacert.pem cacert.pem.orig && mv cacert.pem.new cacert.pem && ls -al"

      echo -ne "Cleaning up...\n"
      rm -rf trustedcerts.pem

      echo -ne "Create semaphore...\n"
      kubectl exec -it $jupyter_lab_pod -n jupyter-lab -- /bin/sh -c "touch /tmp/ssl.sem"

      echo -ne "Done!\n"
   else
      echo -ne "Semaphore found.\n"
   fi
else
   echo -ne "JupyterLab is not running.\n"
fi

exit 0
