Create the resources needed to run JupyterLab on Kubernetes as follows:

- Customize the Dockerfile file in this folder. Once done, run the 
  following command to create a Docker image:

  docker build . -t jupyterlab-viya-aws-1 --no-cache

- Tag the newly created image using the following command:

  docker tag jupyterlab-viya-aws-1 mcazzari/jupyterlab-viya-aws-1:latest

- Push the image to the local registry using the following command:

  docker push mcazzari/jupyterlab-viya-aws-1:latest

  NOTE: the image can be pushed to a different registry if needed. Make 
  sure to tag it appropriately before pushing it. 

- Run (or re-run in case JupyterHub is already up) the following command
  found inside the JupyterHub file in this folder to install JupyterHub:

  helm upgrade --cleanup-on-fail
               --install jupyterhub jupyterhub/jupyterhub   
               --namespace jupyterhub   
               --create-namespace   
               --version=1.2.0   
               --values config.yaml

  NOTE: The above command needs to be run every time the config.yaml file
  changes. If JupyterHub is running, the command restarts it.
  If this is the first time the command executes, make sure to add the repo
  to Helm as shown in the Jupyterhub file inside this folder.
  
- Log on to JupyterLab using a URL similar to the following one:

  http://<server-name>:30080/hub

NOTE:

Once JupyterHub is installed, CAS connectivity can be tested as follows:

- Python:
  Open a new Python3 notebook and paste the following code:

  import swat
  conn = swat.CAS('https://<server-name>:443/cas-shared-default-http/', username='<user>',password='<password>')
  out = conn.serverstatus()
  out

  Where <server-name> is, for instance, iot.viya-aws-1.unx.sas.com

- R:
  Open a new R notebook and paste the following code:

  library(swat)
  conn_rest <- CAS('controller.sas-cas-server-default.sas-viya', 8777, protocol='https', username='<user>', password='<password>')
  conn_rest
