---
category: openSourceConfiguration
tocprty: 1
---

# Configure R for SAS Viya

## Overview

NOTE: The ZIP file stored in this folder is meant to be used to reinstall R on its persistent volume if the Viya namespace is deleted for any reason. That is because R is not installed on the OS and nfs-mounted on the cluster. The persistent volume is shared by the sas-cas-server-default-controller and the sas-microanalytic pods.

To install R: 

1. Unzip the ZIP file:

   gunzip r.tar.gz

2. Copy the file to the CAS controller using a command similar to the following:

   kubectl cp r.tar <viya install namespace>/sas-cas-server-default-controller:/tmp -c cas

3. Using Lens, open a shell for the pod where the file was copied;
4. Change folder to /tmp and untar the file:

   cd /tmp && tar -xvf r.tar

5. Untarring the file will generate a folder called "R". Change directory to it, then move each individual sub-folder to the /external-languages/R (this is the one off of the root folder where R is supposed to be installed):

   cd R 
   mv * /external-languages/R

6. Restart the sas-microanalytic pod, since it cannot run unless R is present. The same is not true for the CAS controller.
7. For good housekeeping, remember to clean up the /tmp folder inside the pod.
8. Re-zip the original tar file:

   gzip r.tar
