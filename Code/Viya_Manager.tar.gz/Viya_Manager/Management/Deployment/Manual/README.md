This directory contains two scripts that are needed to deploy Viya
through the deployment operator:

- SASDeployment: Generates the $(deploy}-sasdeployment.yaml file;
- Deploy: Deploys the $(deploy}-sasdeployment.yaml file previously created.

Be aware that the SASDeployment command looks at the entire folder
where the Viya deployment files are stored when building the yaml
file. Therefore, keep that folder absolutely clean (aka kustomization.yaml,
site-config, and sas-bases folders only).
User root   Host server   Current directory /root/project/deploy/Deployment/Operator
> more ../Manual/README.md
This directory contains two scripts that are needed to deploy Viya
manually:

- Kustomize: Generates the site.yaml file;
- Deploy: Deploys the site.yaml file previously created

However, it's strongly recommended that Viya be deployed using the
SAS Deployment Operator, whose files are located in the Operator
folder parallel to this one.
