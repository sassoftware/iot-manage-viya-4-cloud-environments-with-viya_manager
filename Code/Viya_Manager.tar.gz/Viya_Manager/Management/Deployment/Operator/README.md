This directory contains two scripts that are needed to deploy Viya
through the deployment operator:

- SASDeployment: Generates the $(deploy}-sasdeployment.yaml file;
- Deploy: Deploys the $(deploy}-sasdeployment.yaml file previously created.

Be aware that the SASDeployment command looks at the entire folder
where the Viya deployment files are stored when building the yaml
file. Therefore, keep that folder absolutely clean (aka kustomization.yaml,
site-config, and sas-bases folders only).
