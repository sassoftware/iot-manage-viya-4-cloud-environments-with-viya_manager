This folder contains three directories:

- Manual:
  Contains scripts for the manual deployment of Viya.

- Operator:
  Contains scripts for the deployment of Viya through
  the Deployment Operator.

It's strongly recommended to stick to one installation
method for Viya (Manual or via the Deployment Operator)
as mixing them can cause errors.
