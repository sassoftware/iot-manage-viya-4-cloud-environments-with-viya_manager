This folder contains one directory:

- Operator:
  Contains scripts for the deployment of Viya through
  the Deployment Operator.
