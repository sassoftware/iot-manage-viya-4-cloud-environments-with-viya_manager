The files contained in this folder are for:

1. change_pwd
   This SAS macro allows users to change their LDAP password
   from SAS Studio. The default password is "Change_me!". 
2. LDAP_Manager
   This macro allows the Viya Administrator to add or delete
   a user. When adding users, creating their home folders is
   still a manual operation.
3. Generate_home_folders  
   A script to create users and their home folders. To be run 
   on the appropriate server.
4. Generate_viya_user_list
   A script to generate the manifest that specifies the user
   list for the LDAP database for the cluster. Needs to run on
   a machine that has access to the SAS network.
5. bin folder
   A folder containing the LDAP executables used by #1 and #2.
   The executables need to be copied to the ldap folder on the
   NFS server that is "seen" by SAS compute session.
