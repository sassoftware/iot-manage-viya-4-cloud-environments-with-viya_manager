The files in this folder are used by:

1. <provider>-credentials: 
   This is the default file used by the viya4-iac tool to create 
   the cluster's infrastructure. It stores the credentials needed
   to log on to the Cloud provider.
   To support multiple subscriptions, additional credentials files
   can be created in this folder. Use the -credentials Viya_Manager
   to override the default credentials file.
2. sas_api:
   This file is used by the viya4-deployment and viya4-order tools
   to handle the downloading of orders on behalf of the installer.
   It can hold multiple entries, each one identifying the email
   address of a user authorized to use a specific order along with
   the user's key and secret to access the SAS API portal wrapped
   in single quotes.
   Log on to the SAS API portal site to generate them before using
   Viya_Manager.
3. This file contains the list of tenant IDs and optional password
   for when Viya is installed in multi-tenant mode.
