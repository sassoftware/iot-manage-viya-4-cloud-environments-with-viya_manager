The files contained in this folder are for:

1. gcp.cfg.template
   Template file for the viya4-iac-<provider> tool, used to
   create the cluster's configuration file stored inside the
   cluster's home folder. After the initial deployment, any
   configuration changes to the cluster's infrastructure
   should be made to that file, and the -apply function be
   executed again for them to take effect.
2. locations.gcp.template
   Template file containing the list of regions to choose from
   when creating a cluster.
3. viya.cfg.template
   Template file for the viya4-deployment tool, used to create
   the initial configuration file for a Viya deployment. 
